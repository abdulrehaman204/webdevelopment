// restoring commamds

// git restore -- staged

// (it moves to staging area to working directory)

// git reset --soft Head-1

// (it moves from local repository to stagging area)

// git reset --hard Head-1

// (it moves from local repository to working directory)

// git revert id

// git stash 


let a=10;
let b=20;
console.log(a+b)


function abdul(){
    let ab=20;
    let bc=20;
    console.log(ab+bc)
}


abdul()


