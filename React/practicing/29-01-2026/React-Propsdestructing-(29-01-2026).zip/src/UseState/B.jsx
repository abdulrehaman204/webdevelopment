import React, { useState } from 'react'

const B = () => {

  let [city,setcity]=useState("Hyderabad")
  console.log(city)
  return (
    <div>
      
    </div>
  )
}

export default B
