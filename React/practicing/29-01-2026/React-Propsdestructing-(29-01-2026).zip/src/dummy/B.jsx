import React from 'react'
import D from './D'

function B() {
  return (
    <div>
      B
      <D/>
    </div>
  )
}

export default B

