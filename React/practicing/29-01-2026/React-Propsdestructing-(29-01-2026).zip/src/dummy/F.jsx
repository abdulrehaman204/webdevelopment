import React from 'react'

function F() {
  return (
    <div>
      F
    </div>
  )
}

export default F
