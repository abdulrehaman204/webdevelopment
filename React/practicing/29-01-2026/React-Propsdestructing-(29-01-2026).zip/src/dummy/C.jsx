import React from 'react'
import E from './E'
import F from './F'

function C() {
  return (
    <div>
      C
      <E/>
      <F/>
    </div>
  )
}

export default C
