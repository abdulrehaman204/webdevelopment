import React from 'react'
import B from './B'
import C from './C'

function A() {
  return (
    <div>
      A
      <B/>
      <C/>
    </div>
  )
}

export default A
