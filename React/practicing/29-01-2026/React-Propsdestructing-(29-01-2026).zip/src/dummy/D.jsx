import React from 'react'
import G from './G'
import H from './H'

function D() {
  return (
    <div>
     D
      <G/>
      <H/>
    </div>
  )
}

export default D
