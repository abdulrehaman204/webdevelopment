import React from 'react'

function G() {
  return (
    <div>
      G
    </div>
  )
}

export default G
