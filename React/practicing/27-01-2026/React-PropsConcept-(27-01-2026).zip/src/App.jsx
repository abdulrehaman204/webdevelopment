import React from 'react'
import A from './props/A'
import B from './props/B'

function App() {
  return (
    <div>
      <A/>
      <B/>
    </div>
  )
}

export default App

