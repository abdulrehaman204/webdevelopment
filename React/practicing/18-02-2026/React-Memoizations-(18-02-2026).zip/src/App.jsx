import React from 'react'
import B from './ReactMemo/B'
import A from './UseCallBack/A'
import C from './All/C'
import AB from './project/AB'

function App() {
  return (
    <div>
      {/* <A/> */}
      {/* <B/> */}
      {/* <C/> */}
      <AB/>
    </div>
  )
}

export default App

