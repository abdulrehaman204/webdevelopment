import {createStore} from 'redux'

const initialState = {
  count: 0,
};

function reducer(state = initialState, action) {
  switch (action.type) {
    case 'INCREMENT':
        console.log(action.payload)
      return { count: state.count + 1 };

    case 'DECREMENT':
        console.log(action.payload)
      return { count: state.count - 1 };

    default:
      return state;
  }
}

 export let store=createStore(reducer)