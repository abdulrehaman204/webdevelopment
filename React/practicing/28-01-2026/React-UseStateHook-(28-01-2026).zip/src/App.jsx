import React from 'react'
import Child from './parentTochild/Child'
import A from './childs/A'

function App() {
  return (
    <div>
     {/* <Child/>  */}
     <A/>
    </div>
  )
}

export default App

