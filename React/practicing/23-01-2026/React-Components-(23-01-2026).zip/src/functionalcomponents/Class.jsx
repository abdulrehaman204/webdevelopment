import React, { Component, StrictMode } from 'react'

export default class Class extends Component {
  render() {
    return (
      <StrictMode>
        <h1>Hello! This is Class Components</h1>
      </StrictMode>
    //   <context.provider>
    //      <h1>Hello! This is Class Components</h1>
    //   </context.provider>
    )
  }
}
