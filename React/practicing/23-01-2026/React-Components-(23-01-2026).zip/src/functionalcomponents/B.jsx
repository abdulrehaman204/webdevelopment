import React from 'react'

function B() {
  let a=5;
    return (
    <>
      <h1>Software Company</h1>
      <h1>Top {a} IT company in Hyderabad</h1>
    </>
  )
}

export default B
