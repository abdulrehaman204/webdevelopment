import React, { Suspense } from 'react'

function A() {
  return (
    // <div>
    //   <h1>Welcome To NYB Infotech</h1>
    //   </div>
    <Suspense>
        <h1>Welcome To NYB Infotech</h1>
    </Suspense>
  )
}

export default A
